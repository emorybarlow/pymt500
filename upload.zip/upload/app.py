#!/usr/bin/env python

from datetime import datetime
import exifread
from flask import Flask, render_template, request, jsonify, current_app, send_from_directory, logging as flog
import json
import logging
import os
import shutil
from zipfile import ZipFile


app = Flask(__name__)
app.secret_key = 'secretkeyhereplease'

formatter = logging.Formatter("[%(asctime)s] {%(pathname)s:%(lineno)d} %(levelname)s - %(message)s")
flog.default_handler.setFormatter(formatter)


@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')


@app.route('/download', methods=['GET'])
def download():
    uuid = request.args.get('uuid')

    zip_obj = ZipFile('tmp/sample.zip', 'w')
    for f in os.listdir(os.path.join('tmp', uuid)):
        zip_obj.write(os.path.join('tmp', uuid, f), f)
    zip_obj.close()

    return send_from_directory('tmp', 'sample.zip', as_attachment=True)


@app.route('/cleanup', methods=['DELETE'])
def cleanup():
    uuid = request.args.get('uuid')

    try:
        os.remove('tmp/sample.zip')
        shutil.rmtree(os.path.join('tmp', uuid))
    except:
        pass

    return jsonify()


@app.route('/upload_chunk', methods=['POST'])
def upload_chunk():
    suffix = request.form.get('suffix')
    uuid = request.form.get('uuid')
    count = int(request.form.get('count'))
    current_app.logger.debug(count)
    f = request.files.get('file')
    ext = f.filename.split('.').pop()
    filename = '{}.{}'.format(request.form.get('dzuuid'), ext)

    try:
        os.mkdir(os.path.join('tmp', uuid))
    except:
        pass

    with open(os.path.join('tmp', uuid, filename), 'ab') as fout:
        fout.seek(int(request.form.get('dzchunkbyteoffset')))
        fout.write(f.stream.read())

    chunk = int(request.form.get('dzchunkindex'))
    chunk_count = int(request.form.get('dztotalchunkcount'))
    if chunk+1 == chunk_count:
        fp = open(os.path.join('tmp', uuid, filename), 'rb')
        tags = exifread.process_file(f)
        date_original = tags.get('EXIF DateTimeOriginal')
        if date_original:
            ts = datetime.strptime(str(date_original), '%Y:%m:%d %H:%M:%S')
            ts = ts.strftime('%Y%m%d')
            if count > 0:
                index = '_{}'.format(chr(96+count))
                new_filename = '{}{}{}.{}'.format(ts, suffix, index, ext)
            else:
                new_filename = '{}{}.{}'.format(ts, suffix, ext)
            shutil.move(os.path.join('tmp', uuid, filename), os.path.join('tmp', uuid, new_filename))
        else:
            os.remove(os.path.join('tmp', uuid, filename))
            return jsonify({'error': 'Unable to extract date'}), 400

    return jsonify({'success': True})


if __name__ == '__main__':
    app.run(debug=True)
